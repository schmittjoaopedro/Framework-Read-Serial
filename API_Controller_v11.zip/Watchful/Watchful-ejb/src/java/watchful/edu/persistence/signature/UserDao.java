/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *//*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package watchful.edu.persistence.signature;

import watchful.edu.persistence.beans.User;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author joao.schmitt
 */
@Local
public interface UserDao extends GenericDao {
   
    public List<User> list();
    public List<User> findByCriteriaAndPaginate(Integer start, Integer limit, String filter);
    public Long count();
    public User getSingle(String username);
    
}
