/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package watchful.edu.resources;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import watchful.edu.services.UserService;

/**
 *
 * @author joao.schmitt
 */
@Path("/user")
public class UserResource {
 
    @EJB
    private UserService userService;
    
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/list")
    public Object listUsers() {
        return userService.findAllUser();
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/find/{init}/{limit}/{query}")
    public Object findByCriteriaAndPaginate(@PathParam("init")Integer init,
            @PathParam("limit")Integer limit, @PathParam("query") String query) {
        return userService.findUsersPaginatedByCriteria(init, limit, query);
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/single/{userId}")
    public Object findSingleUserById(@PathParam("userId")Long userId) {
        return userService.getSingle(userId);
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/count")
    public Object findCount() {
        return userService.countUsers();
    }
    
}
