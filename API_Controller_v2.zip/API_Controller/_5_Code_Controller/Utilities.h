#include "Arduino.h"

#ifndef Utilities_h
#define Utilities_h

class Utilities {

//Public members....
public:
	//Contructor...
    Utilities();

    //Methods...
	String readString();

//Private members...
private:

};

#endif
