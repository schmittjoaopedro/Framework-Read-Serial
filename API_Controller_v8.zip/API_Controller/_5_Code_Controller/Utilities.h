#include "Arduino.h"

#ifndef Utilities_h
#define Utilities_h

class Utilities {

//Public members....
public:
	//Contructor...
    Utilities();

    //Methods...
	String readString();
	void reset();

//Private members...
private:

};

#endif
