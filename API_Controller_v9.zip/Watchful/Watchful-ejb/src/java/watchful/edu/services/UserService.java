
package watchful.edu.services;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import wacthful.edu.persistence.commons.JsonTransport;
import watchful.edu.persistence.beans.User;
import watchful.edu.persistence.signature.UserDao;

/**
 *
 * @author joao.schmitt
 */
@Stateless
public class UserService {
    
    @EJB
    protected UserDao userDao;
    
    public Object findAllUser() {
        JsonTransport json = new JsonTransport();
        try{ json.setData(userDao.list()); }
        catch(Exception er) { json.setError(er.getMessage()); }
        return json;
    }
    
    
    public Object findUsersPaginatedByCriteria(Integer init, Integer limit, String criteria) {
        JsonTransport json = new JsonTransport();
        try{ json.setData(userDao.findByCriteriaAndPaginate(init, limit, criteria)); } 
        catch (Exception er) { json.setError(er.getMessage()); }
        return json;
    }
    
    
    public Object countUsers() {
        return userDao.count();
    }
    
    public void persistsUsers(List<User> users) {
        userDao.save(users);
    }
    
    public void deleteUsers(Long id) {
        userDao.delete(id);
    }
    
    public Object getSingle(Long id) {
        JsonTransport json = new JsonTransport();
        try {
            json.setData(userDao.getSingle(id));
        } catch (Exception e) {
            json.setError(e.getMessage());
        }
        return json;
    }
    
    public Object getSingle(String username) {
        JsonTransport json = new JsonTransport();
        try {
            json.setData(userDao.getSingle(username));
        } catch (Exception e) {
            json.setError(e.getMessage());
        }
        return json;
    }
}
