/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package watchful.edu.persistence.beans;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 *
 * @author joao.schmitt
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "User.count", query = "SELECT COUNT(u) FROM User u"),
    @NamedQuery(name = "User.listAll", query = "SELECT u FROM User u"),
    @NamedQuery(name = "User.findPaginateByCriteria", query = "SELECT u FROM User u WHERE u.user LIKE :filter"),
    @NamedQuery(name = "User.findByName", query = "SELECT u FROM User u WHERE u.user = :username")
})
public class User implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private Long id;
    
    @Column(name = "user_login", nullable = false, length = 50)
    private String user;
    
    @Column(name = "user_password" ,nullable = false, length = 50)
    private String password;

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}
