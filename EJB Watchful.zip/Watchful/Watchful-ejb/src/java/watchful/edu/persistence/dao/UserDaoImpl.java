/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *//*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *//*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *//*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package watchful.edu.persistence.dao;

import watchful.edu.persistence.beans.User;
import java.util.List;
import javax.ejb.Stateless;
import watchful.edu.persistence.signature.UserDao;

/**
 *
 * @author joao.schmitt
 */
@Stateless
public class UserDaoImpl extends GenericDaoImpl<Long, User> implements UserDao {

    @Override
    public List<User> list() {
        return getEntityManager().createNamedQuery("User.listAll").getResultList();
    }

    @Override
    public List<User> findByCriteriaAndPaginate(Integer start, Integer limit, String filter) {
        return getEntityManager()
                .createNamedQuery("User.findPaginateByCriteria")
                .setMaxResults(limit)
                .setFirstResult(start)
                .setParameter("filter", "%" + filter + "%")
                .getResultList();
    }

    @Override
    public Long count() {
        return (Long) getEntityManager().createNamedQuery("User.count").getSingleResult();
    }

    @Override
    public User getSingle(String username) {
        return (User) getEntityManager()
                .createNamedQuery("User.findByName")
                .setParameter("username", username)
                .getSingleResult();
    }
    
}