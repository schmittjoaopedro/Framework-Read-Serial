package arduino.watchful.core;

/**
 *
 * @author João Pedro Schmitt
 */
public class DefinitionException extends Exception {
    
    public DefinitionException(String error) {
        super(error);
    }
    
}
